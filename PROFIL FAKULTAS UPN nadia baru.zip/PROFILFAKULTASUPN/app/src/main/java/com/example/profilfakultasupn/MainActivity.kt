package com.example.profilfakultasupn

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textData = createPhoneData()

        rv_part.layoutManager = LinearLayoutManager(this)
        rv_part.setHasFixedSize(true)
        rv_part.adapter = ProfilAdapter(textData) { phoneItem: ProfilData ->
            phoneItemClicked(phoneItem)
        }
    }

    private fun phoneItemClicked(phoneItem: ProfilData) {
        val showDetailActivityIntent = Intent(this, ProfilDetailActivity::class.java)
        showDetailActivityIntent.putExtra(ProfilDetailActivity.EXTRA_ITEM, phoneItem)
        startActivity(showDetailActivityIntent)
    }

    private fun createPhoneData(): List<ProfilData> {
        val partList = ArrayList<ProfilData>()
        partList.add(
            ProfilData(
                "FAKULTAS ILMU KOMPUTER",
                R.drawable.upn,
                "Fakultas Ilmu Komputer merupakan salah satu dari 7 Fakultas di UPN Veteran Jawa Timur." +
                        " Yang terdiri dari program studi :",
                "1. Prodi s1 Teknik Informatika" +
                        "\n2. Prodi s1 Sistem Informasi",
                "",
            "",
            "",
            "",
            "",
            "",
            ""
            )
        )

        partList.add(
            ProfilData(
                " FAKULTAS TEKNIK",
                R.drawable.upn,
                "Fakultas Teknik merupakan salah satu dari 7 Fakultas di UPN Veteran Jawa Timur." +
                            " Yang terdiri dari program studi : ",
                "1. Prodi s1 Teknik Kimia" +
                        "\n2. Prodi s1 Teknik Industri" +
                        "\n3. Prodi s1 Teknik Sipil" +
                        "\n4. Prodi s1 Teknik Lingkungan" +
                        "5. Prodi s1 Teknologi Pangan",
                "",
                "",
                "",
                "",
                "",
                "",
                ""
            )
        )

        partList.add(
            ProfilData(
                "FAKULTAS EKONOMI DAN BISNIS",
                R.drawable.upn,
                "Fakultas Ekonomi dan Bisnis merupakan salah satu dari 7 Fakultas di UPN Veteran Jawa Timur." +
                            " Yang terdiri dari program studi : ",
                "1. Prodi s1 Ekonomi Pembangunan" +
                        "\n2. Prodi s1 Akuntansi" +
                        "\n3. Prodi s1 Manajemen",
                "",
                "",
                "",
                "",
                "",
                "",
                ""
            )
        )

        partList.add(
            ProfilData(
                "FAKULTAS PERTANIAN",
                R.drawable.upn,
                "Fakultas Pertanian merupakan salah satu dari 7 Fakultas di UPN Veteran Jawa Timur." +
                            " Yang terdiri dari program studi : ",
                "1. Prodi s1 Agroteknologi" +
                        "\n2. Prodi s1 Agribisnis ",
                "",
                "",
                "",
                "",
                "",
                "",
                ""
            )
        )

        partList.add(
            ProfilData(
                "NADIA ERINNA RAHMAWATI",
                R.drawable.nadia,
                "===========================================",
                "",
                "TTL : SURABAYA, 06 APRIL 1999",
                "ALAMAT : KENDANGSARI BLOK A NO. 10 SURABAYA",
                "NO.HP : +6289678217008",
                "EMAIL : nadiaerahmawati@gmail.com",
                "URL GITHUB : www.github.com/nadiaerahmawati",
                "RIWAYAT PENDIDIKAN : " +
                        "\n1. TK AL-IKHLAS SURABAYA" +
                        "\n2. SD KENDANGSARI I SURABAYA" +
                        "\n3. SMP NEGERI 35 SURABAYA" +
                        "\n4. MADRASAH ALIYAH NEGERI SURABAYA",
                ""



            )
        )

        return partList
    }
}
